# -*- coding: utf-8 -*-
from . import competency_competency
from . import competency_cluster
from . import competency_role_mapping
from . import competency_skills_test
from . import competency_assessment
from . import competency_coverage_report
from . import competency_data_validator
from . import hr_employee
from . import hr_job
from . import competency_dashboard
from . import competency_dashboard_snapshot
from . import competency_matrix_config
from . import competency_director_peer_config
from . import res_users
from ..wizards import competency_role_mapping_clone_wizard


