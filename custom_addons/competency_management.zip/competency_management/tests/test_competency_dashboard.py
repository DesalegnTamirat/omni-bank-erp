# -*- coding: utf-8 -*-
from odoo.tests.common import TransactionCase


class TestCompetencyDashboard(TransactionCase):

    def setUp(self):
        super(TestCompetencyDashboard, self).setUp()
        self.cycle = self.env['competency.assessment.cycle'].search([], limit=1)
        if not self.cycle:
            self.cycle = self.env['competency.assessment.cycle'].create({
                'name': 'Test Assessment Cycle 2026',
                'state': 'open',
            })

    def test_01_dashboard_metrics_and_persona(self):
        """Test competency dashboard singleton instantiation and metric computations."""
        dashboard = self.env['competency.dashboard'].create({
            'cycle_id': self.cycle.id,
            'persona_role': 'executive',
        })
        self.assertTrue(dashboard.cycle_name)
        self.assertGreaterEqual(dashboard.total_active_competencies, 0)
        self.assertEqual(dashboard.persona_role, 'executive')

        dashboard.persona_role = 'hrbp'
        self.assertEqual(dashboard.persona_role, 'hrbp')

    def test_02_dashboard_snapshot_cron(self):
        """Test automated snapshot generation cron (FR-RPT-010)."""
        snapshot_model = self.env['competency.dashboard.snapshot']
        count = snapshot_model._cron_take_dashboard_snapshot()
        self.assertGreaterEqual(count, 0)

        snapshots = snapshot_model.search([('cycle_id', '=', self.cycle.id)])
        self.assertTrue(snapshots)

    def test_03_scheduled_report_distribution_cron(self):
        """Test scheduled email report distribution cron (FR-RPT-008)."""
        dashboard_model = self.env['competency.dashboard']
        res = dashboard_model._cron_send_scheduled_competency_reports()
        self.assertTrue(res)
