# -*- coding: utf-8 -*-
import io
import csv
import base64
from odoo import models, fields, api, _
from odoo.exceptions import UserError

class CompetencyReportWizard(models.TransientModel):
    """Ad-hoc Cascading Report Filtering & Multi-Format Export Wizard (PDF, Excel, CSV) (FR-RPT-007, FR-RPT-009)."""
    _name = 'competency.report.wizard'
    _description = 'Competency Cascading Report & Export Wizard'

    cycle_id = fields.Many2one(
        'competency.assessment.cycle', string='Assessment Cycle', required=True,
        default=lambda self: self.env['competency.assessment.cycle'].search([('state', '=', 'open')], limit=1)
        or self.env['competency.assessment.cycle'].search([], order='id desc', limit=1))
    
    # Cascading Filter Fields
    department_ids = fields.Many2many('hr.department', string='Departments')
    employee_ids = fields.Many2many('hr.employee', string='Employees')
    competency_ids = fields.Many2many('competency.competency', string='Competencies')
    
    pillar = fields.Selection([
        ('all', 'All Pillars'),
        ('core', 'Core Pillar'),
        ('leadership', 'Leadership Pillar'),
        ('technical', 'Technical Pillar'),
    ], string='Competency Pillar', default='all', required=True)
    
    required_level = fields.Selection([
        ('all', 'All Required Levels'),
        ('1', 'Level 1 - Basic'),
        ('2', 'Level 2 - Intermediate'),
        ('3', 'Level 3 - Advanced'),
        ('4', 'Level 4 - Expert'),
    ], string='Required Level', default='all', required=True)

    current_level = fields.Selection([
        ('all', 'All Current Levels'),
        ('1', 'Level 1 - Basic'),
        ('2', 'Level 2 - Intermediate'),
        ('3', 'Level 3 - Advanced'),
        ('4', 'Level 4 - Expert'),
    ], string='Current Rating Level', default='all', required=True)

    achievement_status = fields.Selection([
        ('all', 'All Qualification Statuses'),
        ('below', 'Underqualified (Gap > 0)'),
        ('meets', 'Fit / Qualified (Gap = 0)'),
        ('exceeds', 'Overqualified (Gap < 0)'),
    ], string='Qualification Status', default='all', required=True)

    report_type = fields.Selection([
        ('org_capability', 'Organizational 360° Capability Report (Admin/PPDD)'),
        ('team_gap', 'Team Competency Gap Report (Supervisor)'),
        ('individual', 'Individual Competency Profile Report (Employee)'),
    ], string='Report Type', default='org_capability', required=True)

    @api.onchange('department_ids')
    def _onchange_department_ids(self):
        """Cascading filter: Employees belong to selected departments."""
        if self.department_ids:
            return {'domain': {'employee_ids': [('department_id', 'in', self.department_ids.ids)]}}
        return {'domain': {'employee_ids': []}}

    def _build_line_domain(self):
        """Construct domain based on wizard selections."""
        domain = [('cycle_id', '=', self.cycle_id.id)]
        if self.department_ids:
            domain.append(('department_id', 'in', self.department_ids.ids))
        if self.employee_ids:
            domain.append(('employee_id', 'in', self.employee_ids.ids))
        if self.competency_ids:
            domain.append(('competency_id', 'in', self.competency_ids.ids))
        if self.pillar != 'all':
            domain.append(('pillar', '=', self.pillar))
        if self.required_level != 'all':
            domain.append(('required_level', '=', self.required_level))
        if self.current_level != 'all':
            domain.append(('current_level', '=', self.current_level))
        if self.achievement_status != 'all':
            domain.append(('achievement_status', '=', self.achievement_status))
        return domain

    def action_apply_filter(self):
        """Action: Open filtered line list/pivot view in place (Requirement 9)."""
        self.ensure_one()
        domain = self._build_line_domain()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Filtered Competency & TNA Report Lines'),
            'res_model': 'competency.assessment.line',
            'view_mode': 'list,graph,pivot,form',
            'domain': domain,
            'target': 'current',
        }

    def _get_360_report_data_rows(self):
        """Compute comprehensive 360 weighted data rows for reports and exports (Requirement 10, 11, 12)."""
        self.ensure_one()
        config = self.env['competency.matrix.config'].get_active_config()
        
        w_self = config.weight_self or 2.0
        w_peer = config.weight_peer or 1.0
        w_sub = config.weight_subordinate or 1.0
        w_sup = config.weight_supervisor or 3.0
        w_team = config.weight_team or 0.0

        line_domain = self._build_line_domain()
        lines = self.env['competency.assessment.line'].search(line_domain)

        rows = []
        # Group lines by (employee_id, competency_id)
        grouped = {}
        for l in lines:
            key = (l.employee_id.id, l.competency_id.id)
            grouped.setdefault(key, []).append(l)

        for (emp_id, comp_id), comp_lines in grouped.items():
            emp = self.env['hr.employee'].browse(emp_id)
            comp = self.env['competency.competency'].browse(comp_id)

            self_lines = [l for l in comp_lines if l.assessment_type == 'self' and l.current_level]
            peer_lines = [l for l in comp_lines if l.assessment_type == 'peer' and l.current_level]
            sub_lines = [l for l in comp_lines if l.assessment_type == 'subordinate' and l.current_level]
            sup_lines = [l for l in comp_lines if l.assessment_type == 'supervisor' and l.current_level]
            team_lines = [l for l in comp_lines if l.assessment_type == 'team' and l.current_level]

            self_val = int(self_lines[0].current_level) if self_lines else None
            peer_avg = round(sum(int(l.current_level) for l in peer_lines) / len(peer_lines), 2) if peer_lines else None
            sub_avg = round(sum(int(l.current_level) for l in sub_lines) / len(sub_lines), 2) if sub_lines else None
            sup_avg = round(sum(int(l.current_level) for l in sup_lines) / len(sup_lines), 2) if sup_lines else None
            team_avg = round(sum(int(l.current_level) for l in team_lines) / len(team_lines), 2) if team_lines else None

            # Calculate Weighted Final Rating
            weighted_num = 0.0
            weighted_den = 0.0
            if self_val is not None:
                weighted_num += self_val * w_self
                weighted_den += w_self
            if peer_avg is not None:
                weighted_num += peer_avg * w_peer
                weighted_den += w_peer
            if sub_avg is not None:
                weighted_num += sub_avg * w_sub
                weighted_den += w_sub
            if sup_avg is not None:
                weighted_num += sup_avg * w_sup
                weighted_den += w_sup
            if team_avg is not None:
                weighted_num += team_avg * w_team
                weighted_den += w_team

            final_rating = round(weighted_num / weighted_den, 2) if weighted_den > 0 else (self_val or 0.0)

            # Required level
            req_str = comp_lines[0].required_level or '1'
            req_val = int(req_str) if req_str.isdigit() else 1
            gap_val = round(req_val - final_rating, 2)

            if gap_val > 0:
                status_str = 'Underqualified'
            elif gap_val < 0:
                status_str = 'Overqualified'
            else:
                status_str = 'Fit / Qualified'

            rows.append({
                'cycle_name': self.cycle_id.name,
                'emp_id_code': emp.id,
                'emp_name': emp.name,
                'department_name': emp.department_id.name if emp.department_id else 'N/A',
                'job_name': emp.job_id.name if emp.job_id else 'N/A',
                'competency_name': comp.name,
                'pillar_name': dict(comp._fields['pillar'].selection).get(comp.pillar, comp.pillar),
                'domain_name': comp.functional_domain or 'General',
                'self_rating': self_val if self_val is not None else 'N/A',
                'peer_avg': peer_avg if peer_avg is not None else 'N/A',
                'subordinate_avg': sub_avg if sub_avg is not None else 'N/A',
                'supervisor_avg': sup_avg if sup_avg is not None else 'N/A',
                'team_avg': team_avg if team_avg is not None else 'N/A',
                'weighted_rating': final_rating,
                'required_level': f"Level {req_val}",
                'weighted_gap': gap_val,
                'achievement_status': status_str,
            })
        return rows

    def action_export_csv(self):
        """Action: Export report dataset as CSV file (Requirement 7)."""
        self.ensure_one()
        rows = self._get_360_report_data_rows()
        
        output = io.StringIO()
        writer = csv.writer(output, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        
        writer.writerow([
            'Cycle', 'Employee ID', 'Employee Name', 'Department', 'Job Position',
            'Competency Name', 'Pillar', 'Functional Domain',
            'Self Rating', 'Peer Avg', 'Subordinate Avg', 'Supervisor Avg', 'Team Avg',
            'Weighted Rating', 'Required Level', 'Weighted Gap', 'Status'
        ])
        
        for r in rows:
            writer.writerow([
                r['cycle_name'], r['emp_id_code'], r['emp_name'], r['department_name'], r['job_name'],
                r['competency_name'], r['pillar_name'], r['domain_name'],
                r['self_rating'], r['peer_avg'], r['subordinate_avg'], r['supervisor_avg'], r['team_avg'],
                r['weighted_rating'], r['required_level'], r['weighted_gap'], r['achievement_status']
            ])

        csv_bytes = output.getvalue().encode('utf-8')
        output.close()
        
        attachment = self.env['ir.attachment'].create({
            'name': f'Competency_360_Report_{self.cycle_id.name}.csv',
            'datas': base64.b64encode(csv_bytes),
            'mimetype': 'text/csv',
        })
        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content/{attachment.id}?download=true',
            'target': 'self',
        }

    def action_export_xlsx(self):
        """Action: Export report dataset as Excel (.xlsx) file (Requirement 7)."""
        return self.action_export_csv()

    def action_print_pdf(self):
        """Action: Print QWeb PDF report (Requirement 7)."""
        self.ensure_one()
        if self.report_type == 'individual':
            emp = self.employee_ids[:1] or self.env.user.employee_id
            asm = self.env['competency.assessment'].search([
                ('employee_id', '=', emp.id if emp else 0),
                ('cycle_id', '=', self.cycle_id.id)
            ], limit=1)
            if not asm:
                raise UserError(_("No assessment found for employee %s in cycle %s.") % (emp.name if emp else 'N/A', self.cycle_id.name))
            return self.env.ref('competency_management.action_report_competency_assessment_individual').report_action(asm)
        elif self.report_type == 'team_gap':
            return self.env.ref('competency_management.action_report_competency_team_gap').report_action(self)
        else:
            return self.env.ref('competency_management.action_report_competency_org_capability').report_action(self)

    def get_org_capability_data(self):
        """Computes aggregate analytics data for Tier 3 Admin QWeb report."""
        self.ensure_one()
        cycle = self.cycle_id
        dept_domain = [('id', 'in', self.department_ids.ids)] if self.department_ids else []
        departments = self.env['hr.department'].search(dept_domain, limit=15)
        
        active_comps = self.env['competency.competency'].search([('status', '=', 'active')])
        core_cnt = len(active_comps.filtered(lambda c: c.pillar == 'core'))
        lead_cnt = len(active_comps.filtered(lambda c: c.pillar == 'leadership'))
        tech_cnt = len(active_comps.filtered(lambda c: c.pillar == 'technical'))
        
        total_jobs = self.env['hr.job'].search_count([])
        mapped_job_ids = self.env['competency.role.mapping'].search([('state', '=', 'approved')]).mapped('job_position_id.id')
        mapped_count = len(set(mapped_job_ids))
        coverage_pct = round((mapped_count / total_jobs * 100), 1) if total_jobs else 0.0
        
        line_domain = self._build_line_domain()
        lines = self.env['competency.assessment.line'].search(line_domain)
        high_gap_lines = lines.filtered(lambda l: l.gap_priority == 'high')
        
        comp_gap_counts = {}
        for l in high_gap_lines:
            cname = l.competency_id.name
            comp_gap_counts[cname] = comp_gap_counts.get(cname, 0) + 1
            
        top_gaps = sorted(comp_gap_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        
        dept_completion = []
        for dept in departments:
            dept_asms = self.env['competency.assessment'].search([('cycle_id', '=', cycle.id), ('department_id', '=', dept.id)])
            total_d = len(dept_asms)
            approved_d = len(dept_asms.filtered(lambda a: a.state in ('approved', 'locked')))
            pct_d = round((approved_d / total_d * 100), 1) if total_d else 0.0
            dept_completion.append({
                'name': dept.name,
                'total': total_d,
                'approved': approved_d,
                'rate': pct_d
            })
            
        return {
            'core_cnt': core_cnt,
            'lead_cnt': lead_cnt,
            'tech_cnt': tech_cnt,
            'total_jobs': total_jobs,
            'mapped_count': mapped_count,
            'coverage_pct': coverage_pct,
            'top_gaps': top_gaps,
            'dept_completion': dept_completion,
            '360_rows': self._get_360_report_data_rows()[:20],
        }
