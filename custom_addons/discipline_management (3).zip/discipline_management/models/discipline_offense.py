# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class DisciplineOffenseCategory(models.Model):
    _name = 'discipline.offense.category'
    _description = 'Disciplinary Offense Category'
    _order = 'name'

    name = fields.Char(string='Category Name', required=True)
    code = fields.Char(string='Category Code', required=True)
    description = fields.Text(string='Description')
    active = fields.Boolean(default=True)
    offense_ids = fields.One2many('discipline.offense', 'category_id', string='Offenses')

    _sql_constraints = [
        ('code_uniq', 'unique(code)', 'The Category Code must be unique!')
    ]


class DisciplineOffense(models.Model):
    _name = 'discipline.offense'
    _description = 'Disciplinary Offense Definition'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'severity_level, name'

    name = fields.Char(string='Offense Title', required=True, tracking=True)
    category_id = fields.Many2one('discipline.offense.category', string='Offense Category', required=True, tracking=True)
    severity_level_id = fields.Many2one('discipline.severity.level', string='Default Severity Level', tracking=True)
    severity_level = fields.Char(related='severity_level_id.code', string='Severity Level Code', store=True, readonly=True)

    description = fields.Text(string='Offense Description & Guidelines')
    active = fields.Boolean(default=True, tracking=True)
    policy_version_id = fields.Many2one('discipline.policy.version', string='Policy Version', tracking=True)

    punishment_type = fields.Selection([
        ('dismissal', 'Dismissal / Separation'),
        ('demotion', 'Demotion to Lower Grade / Position'),
        ('final_warning_penalty', 'Final Warning + Penalty'),
        ('second_warning_penalty', 'Second Warning + Penalty'),
        ('first_warning_penalty', 'First Warning + Penalty'),
        ('verbal_warning', 'Recorded Verbal Warning'),
        ('custom', 'Custom Administrative Action'),
    ], string='Default Applicable Punishment', default='first_warning_penalty', tracking=True)

    penalty_percentage = fields.Float(string='Default Penalty Percentage (%)', default=0.0, tracking=True)
    fine_days = fields.Float(string='Default Salary Fine (Days)', default=0.0, tracking=True)
    approval_authority = fields.Selection([
        ('direct_manager', 'Direct Manager / Coach'),
        ('hr_manager', 'HR Manager / Directorate'),
        ('executive', 'Executive HR / Disciplinary Committee'),
        ('cpco', 'Chief People Officer (CPCO)'),
        ('ceo', 'Chief Executive Officer (CEO)'),
    ], string='Default Approval Authority', default='direct_manager', tracking=True)

    line_ids = fields.One2many('discipline.offense.line', 'offense_id', string='Severity Escalation Lines', copy=True)

    @api.onchange('severity_level_id')
    def _onchange_severity_level_id(self):
        if self.severity_level_id:
            lvl = self.severity_level_id
            if not self.punishment_type or self.punishment_type == 'first_warning_penalty':
                self.punishment_type = lvl.default_punishment_type
            self.penalty_percentage = lvl.default_penalty_percentage
            self.fine_days = lvl.default_fine_days
            self.approval_authority = lvl.default_approval_authority

    @api.onchange('category_id')
    def _onchange_category_populate_lines(self):
        """Auto-populate all active Severity Levels as default escalation lines if grid is empty."""
        if not self.line_ids:
            self.action_populate_default_severity_lines()

    def action_populate_default_severity_lines(self):
        """Pre-fill offense escalation lines from all active Severity Levels."""
        levels = self.env['discipline.severity.level'].search([('active', '=', True)], order='sequence, id')
        lines = []
        for idx, lvl in enumerate(levels, start=1):
            lines.append((0, 0, {
                'severity_level_id': lvl.id,
                'occurrence_number': idx,
                'punishment_type': lvl.default_punishment_type,
                'non_managerial_penalty_pct': lvl.default_non_managerial_penalty_pct or lvl.default_penalty_percentage,
                'non_managerial_fine_days': lvl.default_non_managerial_fine_days or lvl.default_fine_days,
                'managerial_penalty_pct': lvl.default_managerial_penalty_pct or lvl.default_penalty_percentage,
                'managerial_fine_days': lvl.default_managerial_fine_days or lvl.default_fine_days,
                'reset_window_months': lvl.default_reset_window_months or 3,
                'approval_authority': lvl.default_approval_authority,
            }))
        if lines:
            self.line_ids = [(5, 0, 0)] + lines

    @api.model_create_multi
    def create(self, vals_list):
        # Modification Prevention - Only HR Admin can configure punishment rules
        if not (self.env.su or self.env.user.has_group('discipline_management.group_discipline_admin')):
            raise UserError(_('Unauthorized modification: Only HR Administrators can create disciplinary offense configurations.'))
        return super().create(vals_list)

    def write(self, vals):
        # Modification Prevention
        sensitive_fields = {'severity_level', 'punishment_type', 'penalty_percentage', 'approval_authority'}
        if set(vals.keys()).intersection(sensitive_fields):
            if not (self.env.su or self.env.user.has_group('discipline_management.group_discipline_admin')):
                raise UserError(_('Unauthorized modification: Only HR Administrators can update disciplinary punishment rules and severity levels.'))
        return super().write(vals)
