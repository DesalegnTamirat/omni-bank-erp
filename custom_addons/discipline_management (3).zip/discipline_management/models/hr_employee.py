# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import timedelta


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    # Disciplinary History Smart Fields
    is_managerial = fields.Boolean(
        string='Is Managerial Staff',
        compute='_compute_is_managerial',
        store=True,
        readonly=False,
        help='Indicates whether employee belongs to Managerial Staff (uses managerial penalty rates)'
    )
    active_disciplinary_action = fields.Boolean(
        string='Has Active Disciplinary Action',
        default=False,
        help='Indicates whether employee has an active/enforced disciplinary warning or pending case',
        tracking=True
    )
    disciplinary_warning_count = fields.Integer(
        string='Total Disciplinary Warnings',
        default=0,
        readonly=True,
        tracking=True
    )
    last_disciplinary_date = fields.Date(
        string='Last Disciplinary Action Date',
        readonly=True,
        tracking=True
    )
    is_suspended = fields.Boolean(
        string='Currently Suspended',
        default=False,
        readonly=True,
        tracking=True
    )
    suspension_type = fields.Selection([
        ('with_pay', 'Suspension With Pay'),
        ('without_pay', 'Suspension Without Pay'),
    ], string='Active Suspension Type', readonly=True)

    is_ineligible_for_promotion_transfer = fields.Boolean(
        string='Ineligible for Promotion / Transfer',
        default=False,
        help='Automatically set to True when active disciplinary penalties (warnings, demotion) are enforced.',
        tracking=True
    )

    discipline_case_ids = fields.One2many(
        'discipline.case',
        'employee_id',
        string='Disciplinary Cases History'
    )
    discipline_case_count = fields.Integer(
        string='Disciplinary Cases Count',
        compute='_compute_discipline_case_count'
    )

    @api.depends('discipline_case_ids')
    def _compute_discipline_case_count(self):
        for emp in self:
            emp.discipline_case_count = len(emp.discipline_case_ids)

    def check_discipline_eligibility(self, action_type='promotion', is_forced=False):
        """
        Check if employee is eligible for promotion, transfer, or internal recruitment.
        :param action_type: 'promotion', 'transfer', or 'recruitment'
        :param is_forced: Boolean - True if HR/Management is executing an administrative/forced transfer
        :return: (is_eligible: bool, reason: str)
        """
        self.ensure_one()
        if self.is_suspended:
            return (False, _('Employee is currently under active disciplinary suspension (%s).') % (self.suspension_type or 'Standard'))
        
        # Administrative / forced transfer initiated by HR/Management is always permitted
        if action_type == 'transfer' and is_forced:
            return (True, _('Administrative transfer permitted for operational or disciplinary reassignment.'))

        if self.is_ineligible_for_promotion_transfer:
            return (False, _('Candidate is currently ineligible for promotion/transfer due to an active disciplinary penalty.'))
        
        today = fields.Date.context_today(self)
        active_cases = self.discipline_case_ids.filtered(
            lambda c: c.state == 'enforced' and (
                (c.active_penalty_end_date and c.active_penalty_end_date >= today) or
                (not c.active_penalty_end_date and c.final_decision_date and c.final_decision_date >= (today - timedelta(days=365)))
            ) and (c.severity_level in ['level_1', 'level_2'] or c.punishment_type in ['dismissal', 'demotion', 'final_warning_penalty'])
        )
        if active_cases:
            case_names = ", ".join(active_cases.mapped('name'))
            return (False, _('Candidate is currently ineligible for promotion due to an active disciplinary penalty (Cases: %s).') % case_names)
        
        return (True, _('Employee is eligible.'))

    @api.model
    def _cron_revert_ineligibility(self):
        """Cron job: automatically revert ineligibility flag once legal active penalty period expires."""
        today = fields.Date.context_today(self)
        ineligible_employees = self.search([
            ('is_ineligible_for_promotion_transfer', '=', True),
            ('is_suspended', '=', False),
        ])
        for emp in ineligible_employees:
            active_recent_cases = emp.discipline_case_ids.filtered(
                lambda c: c.state == 'enforced' and (
                    (c.active_penalty_end_date and c.active_penalty_end_date >= today) or
                    (not c.active_penalty_end_date and c.final_decision_date and c.final_decision_date >= (today - timedelta(days=365)))
                ) and (c.severity_level in ['level_1', 'level_2'] or c.punishment_type in ['dismissal', 'demotion', 'final_warning_penalty'])
            )
            if not active_recent_cases:
                emp.with_context(no_leave_resource_calendar_update=True).write({
                    'is_ineligible_for_promotion_transfer': False,
                    'active_disciplinary_action': False,
                })

    @api.depends('job_id', 'job_id.name')
    def _compute_is_managerial(self):
        for emp in self:
            job_name = (emp.job_id.name or '').lower() if emp and emp.job_id else ''
            if emp.job_id and getattr(emp.job_id, 'is_managerial', False):
                emp.is_managerial = True
            elif any(kw in job_name for kw in ['manager', 'director', 'chief', 'head', 'vp', 'supervisor', 'president', 'officer in charge']):
                emp.is_managerial = True
            else:
                emp.is_managerial = False

    def action_view_discipline_cases(self):
        self.ensure_one()
        return {
            'name': _('Disciplinary Cases History'),
            'type': 'ir.actions.act_window',
            'res_model': 'discipline.case',
            'view_mode': 'list,form',
            'domain': [('employee_id', '=', self.id)],
            'context': {'default_employee_id': self.id}
        }


class HrJob(models.Model):
    _inherit = 'hr.job'

    is_managerial = fields.Boolean(
        string='Is Managerial Position',
        default=False,
        help='Check if this job position belongs to Managerial Staff'
    )
