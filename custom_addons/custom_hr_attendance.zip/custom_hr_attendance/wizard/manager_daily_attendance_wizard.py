from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class ManagerDailyAttendanceWizard(models.TransientModel):
    """
    Lightweight wizard for managers to view their subordinate employees'
    attendance for a specific date. Unlike the branch-level report wizard
    (generate.detail.employee.attendance.report), this does NOT write to
    the generate_employee_attendance_details table. It returns a filtered
    list action directly so the manager sees live hr.attendance records.
    """
    _name = 'manager.daily.attendance.wizard'
    _description = 'Manager Daily Attendance Wizard'

    date_from = fields.Date(
        string='From Date',
        required=True,
        default=fields.Date.context_today,
    )
    date_to = fields.Date(
        string='To Date',
        required=True,
        default=fields.Date.context_today,
    )
    @api.model
    def _get_subordinate_domain(self):
        if self.env.user.has_group('hr_attendance.group_hr_attendance_manager'):
            return [('active', '=', True)]
        user = self.env.user
        manager_employee = user.employee_id
        if manager_employee:
            return [
                ('active', '=', True),
                '|', '|', '|',
                ('user_id', '=', user.id),
                ('parent_id.user_id', '=', user.id),
                ('attendance_manager_id', '=', user.id),
                ('id', 'child_of', manager_employee.id)
            ]
        return [('user_id', '=', user.id), ('active', '=', True)]

    employee_ids = fields.Many2many(
        'hr.employee',
        string='Employees',
        domain=lambda self: self._get_subordinate_domain(),
        help="Leave empty to include all employees under your management.",
    )
    include_all = fields.Boolean(
        string='Include All My Employees',
        default=True,
        help="When checked, all subordinate employees are included regardless of the Employees selection.",
    )

    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        for rec in self:
            if rec.date_from and rec.date_to and rec.date_from > rec.date_to:
                raise ValidationError(_("From Date cannot be greater than To Date."))

    def _get_subordinate_employee_ids(self):
        """
        Collect all employee IDs under this manager.
        """
        domain = self._get_subordinate_domain()
        return self.env['hr.employee'].search(domain).ids

    def action_generate_report(self):
        """
        Generates daily attendance report for the selected date range by calling the
        generate_detail_employee_attendance_report stored procedure to populate the
        generate_employee_attendance_details table, then opens the Daily Employee Attendance Detail view.
        """
        self.ensure_one()

        # Execute stored procedure to populate generate_employee_attendance_details table
        self.env.cr.execute(
            "SELECT generate_daily_employee_attendance_detail_report(%s, %s, %s)",
            (self.date_from, self.date_to, 'daily_detail')
        )

        return {
            'type': 'ir.actions.act_window',
            'name': _('Daily Employee Attendance Detail'),
            'res_model': 'generate.employee.attendance.details',
            'view_mode': 'list,search',
            'views': [(self.env.ref('custom_hr_attendance.view_daily_employee_attendance_detail_tree').id, 'list')],
            'target': 'current',
        }

    # Backward-compatibility alias
    action_view_attendance = action_generate_report

