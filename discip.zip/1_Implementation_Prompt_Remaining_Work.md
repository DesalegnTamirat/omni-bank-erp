# Implementation Prompt — Discipline Management Remaining Work

Copy everything below the line into your AI coding assistant (Claude Code, etc.) with the
`discipline_management` module open in the workspace. It's written as a single prompt but
organized into independently-executable tasks — you can paste the whole thing, or hand over
one task at a time if you want to review each before moving to the next.

Each task lists: the BRD requirement it satisfies, the files it touches, what to build, and
an acceptance check so you (or the AI) can confirm it's actually done before moving on.

---

## Context to give the AI first

```
This is an Odoo 19 module called discipline_management, implementing Module 9 (Discipline
Management System) of a bank's ERP HR BRD. The core case lifecycle, suspension, appeal, and
revocation flows are already built and working. I need you to complete the remaining gaps
listed below. Follow the existing code style: mail.thread tracking on all models, FR-DIS-xxx
references in comments, Odoo 19 new-style view attributes (invisible="..." not attrs=...),
segregation-of-duties and security-group patterns already used in discipline_case.py and
discipline_offense.py. Do not change working functionality outside the scope of each task.
After each task, tell me exactly what you changed and which files.
```

---

## Task 1 — Appeal submission window: gate the UI, not just the ORM (FR-DIS-031, FR-DIS-032)

**This is a discipline_management responsibility, not an ESS/portal-module responsibility** —
the field that decides open/closed already lives here (`discipline.case.is_appeal_window_open`).
Right now only the ORM constraint (`_check_appeal_window`) rejects a late appeal; there's no
UI that visibly shows the button as open/locked before the employee tries.

**Files:** `models/discipline_appeal.py`, `views/discipline_appeal_views.xml`,
`models/discipline_case.py`, `__manifest__.py`

**Build:**
1. Add `depends: ['portal']` to the manifest (needed for a self-service page — see step 4).
2. On `discipline.case`, expose `is_appeal_window_open` and `appeal_deadline` as already done —
   no change needed there, just confirm they're `store=True`-safe for use in domains (they
   currently are not `store=True`; either add storage or keep them compute-only and only use
   them for view attributes, not search domains).
3. In `views/discipline_appeal_views.xml`, add a "New Appeal" smart button on the
   `discipline.case` form (not just the generic Appeals menu) that is:
   - `invisible="not is_appeal_window_open"` when the case is enforced and no appeal exists yet
   - Replace it with a plainly-labeled disabled/greyed state once the window closes, e.g. a
     `<field name="is_appeal_window_open" invisible="1"/>` driven banner: "Appeal window closed
     on [date]" shown when `state == 'enforced' and not is_appeal_window_open`.
4. Add a portal controller + template (`controllers/portal.py`, `views/portal_templates.xml`)
   so an employee can see their own enforced cases and submit an appeal from a self-service
   page — reusing the existing record rule `rule_discipline_case_employee` for data access.
   The controller must re-check `is_appeal_window_open` server-side before accepting a POST
   (never trust the button being hidden client-side as the only control).
5. Keep the existing `_check_appeal_window` ORM constraint as the final safety net — defense
   in depth, not a replacement for the UI gating.

**Acceptance check:** As an employee user, opening an enforced case within 10 days shows an
active "Submit Appeal" button/link; after day 10, the same spot shows a locked/closed message
instead, and attempting to force a POST past the deadline still gets rejected server-side.

---

## Task 2 — Payroll penalty calculation rewrite (FR-DIS-019, FR-DIS-021, FR-DIS-022, FR-DIS-030)

**Files:** `models/discipline_payroll.py`, `models/discipline_case.py`, `models/hr_employee.py`,
`__manifest__.py`, `security/ir.model.access.csv` (if new fields need access rules)

**Build:**
1. Add a `staff_category` computed or related field (e.g. `is_managerial` boolean) on
   `hr.employee` — derive it from `hr.job` or `hr.contract` grade if such a field already
   exists in the base HR setup; otherwise add a manual `Selection`/`Boolean` field HR can set.
2. Rewrite `discipline.payroll.penalty` to branch on this flag:
   - **Managerial**: penalty is a **day count**, not a percentage — Verbal=0 days,
     1st Written=1 day, 2nd Written=2 days, 3rd Written=3 days. Store `penalty_days` and
     compute `calculated_amount` as `(monthly_wage / working_days_in_month) * penalty_days`.
   - **Non-managerial**: keep existing percentage logic (5/10/20%).
3. Add **Demotion** handling: when `punishment_type` implies demotion, do NOT touch
   `contract.wage` (Basic Salary stays the same per BRD), but update the employee's
   `job_id`/grade-linked allowance and benefit fields to the new (lower) grade's scale. This
   needs a mapping table or field on `hr.job` for "benefit scale" — confirm with the client
   what fields represent "allowances/benefits" in your `hr.contract`/`hr.job` setup before
   coding this, since the BRD doesn't specify the exact field names.
4. Add the `hr_payroll` dependency (or confirm with the team whether Payroll will be a
   separate custom module) and, once available, replace the manual
   `action_transmit_to_payroll` button with actually creating an `hr.payslip.input` line (or
   equivalent) so FR-DIS-023's "automatically transmit" is a real integration, not a status
   flag. If `hr_payroll` isn't installed yet, leave a clearly marked `TODO` and keep the
   current manual-button behavior as a safe fallback.
5. **Suspension → payroll**: for `without_pay` suspensions, create a corresponding payroll
   deduction/zero-pay record for the suspension period (mirroring how penalties work), so
   FR-DIS-030 ("suspension from... salary") actually withholds pay rather than just blocking
   attendance check-in.

**Acceptance check:** Creating a case for a managerial employee with a "1st written warning"
offense produces a 1-day-wage deduction, not a 5% deduction. Creating one for a non-managerial
employee still produces the correct percentage. A demotion case updates the employee's benefit
scale without touching Basic Salary. A without-pay suspension produces a payroll record.

---

## Task 3 — Approval authority by job level (FR-DIS-011)

**Files:** `models/discipline_case.py`

**Build:**
1. Add a way to determine if the employee under investigation is "Division Manager and above"
   — likely a field/flag on `hr.job` (`job_level` or similar) or a manually maintained list of
   qualifying job positions.
2. In `_validate_segregation_of_duties()` (or a new dedicated method), branch the final-approver
   check:
   - Employee is Division Manager or above → `approver_id` must belong to the CEO
     designation/group.
   - Employee is below Division Manager → `approver_id` must belong to the CPCO
     designation/group.
3. Add two new security groups or `res.users` flags (`is_ceo_approver`, `is_cpco_approver`) if
   they don't already map cleanly onto the existing `group_discipline_admin` group — confirm
   with HR whether CEO/CPCO should be a new dedicated group, since right now everything funnels
   through one `admin` group.

**Acceptance check:** Attempting to approve a case for a Division-Manager-level (or above)
employee with a non-CEO approver is rejected with a clear error; the equivalent case for a
regular employee is rejected if approved by anyone other than a CPCO-flagged user.

---

## Task 4 — Committee sequential sign-off (FR-DIS-020)

**Files:** `models/discipline_committee.py`, `views/discipline_committee_views.xml`

**Build:**
1. Add three sign-off fields/steps to `discipline.committee.meeting`:
   - `director_signoff_id` / `director_signoff_date` — first signatory (Immediate Director)
   - Keep existing `vote_ids` for committee members as step 2
   - `final_approver_signoff_id` / `final_approver_signoff_date` — step 3
2. Add a computed `can_finalize` boolean: `True` only when director has signed AND all expected
   committee members have voted. Use this to control button visibility/`readonly` on the final
   approval action, instead of only the quorum-percentage check that exists today.
3. Update `action_finalize_meeting()` to raise a clear error if `can_finalize` is False, listing
   which step is incomplete (e.g. "Immediate Director has not yet signed").

**Acceptance check:** The final-approval button/action is disabled until the Director has
signed and quorum-required votes are in; a case cannot skip straight to CEO/CPCO approval.

---

## Task 5 — Structured investigation report fields (FR-DIS-013)

**Files:** `models/discipline_investigation.py`, `views/discipline_investigation_views.xml`,
`report/discipline_report_templates.xml` (if investigation data feeds any report)

**Build:** Replace/extend the current 3 free-text fields with the BRD's 8-part structure:
```python
title_subject = fields.Char(string='Title / Subject', required=True)
introduction = fields.Text(string='Introduction')
scope_limitations = fields.Text(string='Scope & Limitations of Investigation')
summary_findings = fields.Text(string='Investigation Findings', required=True)  # existing
financial_loss_amount = fields.Monetary(string='Financial Shortage / Loss Amount', currency_field='currency_id')
resolution_status = fields.Selection([('resolved', 'Resolved'), ('unresolved', 'Unresolved'), ('not_applicable', 'Not Applicable')])
liable_employee_ids = fields.One2many('discipline.investigation.liable', 'investigation_id', string='Liable Employees & Policy Violations')
investigator_recommendation = fields.Text(string='Recommendations', required=True)  # existing
```
Create a small child model `discipline.investigation.liable` with `employee_id`,
`policy_article_ref` (Char), and `notes` (Text) so multiple liable staff can be listed with
their specific policy references, as the BRD requires.

**Acceptance check:** Opening an investigation form shows all 8 sections; a case involving
multiple liable employees lets you list each one with their own policy-article reference.

---

## Task 6 — Auto-generate and attach the warning letter on approval (FR-DIS-022)

**Files:** `models/discipline_case.py`, `report/discipline_reports.xml`

**Build:** In `action_approve_and_enforce()`, after setting state to `enforced`, call the
existing report action to render the PDF and attach it as an `ir.attachment` on the case
record automatically (Odoo's `report_action(...).render_qweb_pdf(...)` pattern), instead of
only relying on a manual "Print" click. Post the attachment reference in the chatter message
that currently just says "Warning letter generated" — make that claim true.

**Acceptance check:** Approving a case immediately produces a PDF attachment on the case
record, visible in the chatter, without any manual print action.

---

## Task 7 — Fix known bugs (no BRD mapping, but should be cleaned up)

**Files:** `models/discipline_dashboard.py`, `models/discipline_suspension.py`

1. `discipline_dashboard.py`: fix the `investigations` count filter — `discipline.investigation`
   has no `'concluded'` state (only `draft/submitted/approved`); decide what "active" should
   mean (probably `state != 'approved'`) and fix the filter. Fix the same issue for
   `committee_meetings` — filter should exclude `'completed'` and `'cancelled'`, not
   `'concluded'` and `'cancelled'`.
2. `discipline_suspension.py`: either implement a real transition into the
   `'converted_dismissal'` state (e.g. an `action_convert_to_dismissal()` method that also
   triggers the case's dismissal flow), or remove the unused state option entirely if it's not
   needed yet.

**Acceptance check:** Dashboard counts change correctly when investigations/meetings move
through their real states. `converted_dismissal` either has a working action button or is
removed from the selection list.

---

## Task 8 — Duplicate/penalty sub-rules (FR-DIS-009) and workflow auto-routing (FR-DIS-010)

**Files:** `models/discipline_case.py`

**Build:**
1. Extend `_check_duplicate_case()` to also reject creating a **second case at the same
   severity level** for the same employee on the same incident date, even if the specific
   offense type differs (per the BRD's "cannot receive the same level of penalty for an
   additional offense discovered on the same day" rule).
2. Add a per-offense-level "active duration" concept (e.g. a field on `discipline.offense` for
   how long a penalty stays "active" for eligibility-blocking purposes) — confirm exact
   durations per level with the client, since the BRD doesn't specify them numerically.
3. For FR-DIS-010, add a computed `suggested_approver_id` based on the employee's manager
   chain and offense severity, and pre-fill (not force) the `approver_id`/`reviewer_id` fields
   when a case is created, so routing has some automation instead of being fully manual.

**Acceptance check:** Two different offenses at the same level, same employee, same day, are
blocked. Case creation suggests (auto-fills) a sensible approver based on org hierarchy.

---

## Task 9 — Expand automated tests

**Files:** `tests/test_discipline_case.py` and new test files per model

Add coverage for: committee quorum validation and sequential sign-off (once Task 4 lands),
revocation wizard flow, payroll penalty calculation (managerial vs non-managerial, once Task 2
lands), dismissal handling (`_process_employee_dismissal`), and the three cron methods
(`_cron_check_sla_escalations`, `_cron_check_suspension_expiry`,
`_cron_check_appeal_window_expiry`) using Odoo's `freeze_time`/date-mocking test utilities.

**Acceptance check:** `test_discipline_case.py` (and any new test files) pass with
`odoo-bin -i discipline_management --test-enable --stop-after-init`, and coverage includes
every model that currently has zero tests.

---

## Suggested execution order

Task 1 (appeal UI fix — quick, directly from your review comment) → Task 7 (bug fixes — quick) →
Task 5 (investigation fields) → Task 3 (approval authority) → Task 4 (committee sign-off) →
Task 2 (payroll rewrite — biggest, do after the simpler ones so patterns are established) →
Task 6 (auto letter) → Task 8 (duplicate/routing rules) → Task 9 (tests, last, covering
everything above).
