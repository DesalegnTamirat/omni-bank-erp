# Attendance ↔ Discipline — Full Bidirectional Scenario List

Since you own both modules, this lays out every scenario the BRD implies or requires between
Attendance and Discipline in both directions, what's already built, and how to implement what's
missing. Where a cron would normally be reached for, this file follows the "lightweight over
cron" guidance from `3_Cron_Performance_Review.md` — most of these should NOT be cron-driven.

---

## Current state summary

| Direction | Built? | Where |
|---|---|---|
| Discipline → Attendance (suspension blocks check-in) | ✅ Partial | `hr_attendance.py` |
| Discipline → Attendance (suspension shown on attendance record) | ✅ | `hr_attendance.py` compute field |
| Attendance → Discipline (any direction) | ❌ Not built | FR-INT-010 — nothing exists yet |

The BRD's FR-INT-010 ("Attendance to Discipline: the system shall automatically initiate or
update discipline case") is the missing half. Everything in Section 2 below is new work.

---

## SECTION 1 — Discipline → Attendance (mostly built, here's what's left)

### 1.1 Suspension (without pay) blocks check-in — ✅ built
**Current behavior:** `_check_unpaid_suspension_attendance` raises a `ValidationError` if a
`without_pay`-suspended employee's attendance record is created/written.
**Gap (see cron-performance file, section 2):** this is a live cross-model Python constraint
on every write — replace with a denormalized local field for performance at scale, same fix
either way, not a functional gap.

### 1.2 Suspension (with pay) does NOT block check-in — ✅ built correctly
The constraint only fires for `suspension_type == 'without_pay'`, which matches BRD intent —
an employee suspended with pay still isn't necessarily expected to attend, but nothing in the
BRD says to block their attendance record either; this is a reasonable existing behavior, just
confirm with HR that "with pay" suspended employees are in fact expected to stay away from work
(if so, you may want to block check-in for BOTH types and only differ on whether pay is
withheld — worth a quick confirmation, not a code gap).

### 1.3 Dismissal (Level 1) stops all future attendance — 🟡 partially built
**Current behavior:** `_process_employee_dismissal()` sets `active = False` on the employee and
disables their `user_id`. Odoo's base attendance UI generally won't let an archived employee
check in through the normal kiosk/portal flow.
**Gap:** if attendance comes through a **biometric device API** rather than the Odoo UI/portal
(common for banks), the device integration may create `hr.attendance` records directly via API
calls that don't check `employee.active` — only the discipline module's own constraint (1.1)
would catch it, and only for suspension, not dismissal.
**Fix:** extend the same denormalized-field approach from 1.1: also block attendance creation
for employees with `active == False`, as a defense-in-depth check independent of however the
record got created (UI, portal, or device API import).

### 1.4 Suspension expiry reinstates check-in ability — ✅ built
`action_reinstate_employee()` clears `is_suspended`, which removes the block automatically —
no extra work needed here.

---

## SECTION 2 — Attendance → Discipline (not built — this is the real gap, FR-INT-010)

The BRD's business rules (Section 16.3 doesn't explicitly enumerate these, but FR-INT-010 and
the offense category data you already seeded — `ATT` "Attendance & Punctuality Misconduct" —
imply the following concrete scenarios).

### 2.1 Repeated unexcused absence → auto-draft a discipline case
**Trigger:** an employee accumulates N unexcused absences within a rolling window (e.g. 3
unexcused absences in 30 days — **confirm the exact threshold with HR/the client**, the BRD
doesn't give a specific number for this one).
**What should happen:** auto-create a `discipline.case` in **`draft` state** (never
auto-enforce — a human always reviews before anything is initiated for real), pre-filled with:
- `employee_id` = the employee
- `offense_id` = whichever offense in the `ATT` category matches (needs a specific offense
  record seeded for "Repeated Unexcused Absence" — check if `discipline_offense_data.xml`
  already has one; if not, add it)
- `description` = auto-generated text listing the specific absence dates
- A flag or chatter note saying "Auto-drafted from attendance pattern — requires HR review
  before initiation."
**How to implement (lightweight, not cron-driven):** use a **narrowly-scoped Automated Action**
(`base.automation`) triggered on `hr.attendance` create, but the *triggering condition* should
not run this check on every single check-in — only evaluate it when a record represents an
**absence** (however your attendance setup marks a day as absent — likely a separate leave/
absence record or a missing-checkin end-of-day batch marker, not the `hr.attendance` check-in
model itself, since `hr.attendance` only has rows for people who *did* check in). If absences
are tracked via `hr.leave`/a custom absence model, hook the automation there instead —
whichever model actually gets written to when an absence is recorded, not on every attendance
swipe. This keeps it event-driven and cheap, per the cron-performance file's guidance table.

### 2.2 Habitual lateness pattern → notify, don't auto-case
**Trigger:** an employee is late beyond a grace period N times in a rolling window.
**What should happen:** unlike absence (2.1), lateness is more judgment-dependent — recommend
just raising an **activity/notification** to the employee's manager or HR ("Employee X has been
late 5 times this month — review for possible discipline referral") rather than auto-creating a
case. Let a human decide whether to formally initiate. This avoids over-triggering cases for
minor patterns and keeps the discipline pipeline meaningful.
**How to implement:** same event-driven automated-action pattern as 2.1, but the action is
`mail.activity.create()` on the employee/manager rather than `discipline.case.create()`. This
is lighter than a full case and appropriately less severe than 2.1.

### 2.3 Job abandonment (no check-in for X consecutive working days) → auto-draft a case
**Trigger:** zero attendance records for an employee across X consecutive scheduled working
days (this is explicitly a Level-appropriate offense category — likely maps to a higher
severity than ordinary absence).
**What should happen:** similar to 2.1 — auto-draft (never auto-enforce) a case, pre-filled
with the date range and a note.
**How to implement — this is the one case in this whole document where a cron actually IS the
right tool**, because "nothing happened for X days" is fundamentally a check for the *absence*
of records, which by definition can't be triggered by a record being written (there's nothing
to hook onto). This has to be a periodic scan. Keep it:
- **Daily, off-peak** (same pattern as the existing 3 crons — see cron-performance file)
- Scoped to a single indexed query: employees with no attendance record where
  `max(check_in) < today - X days`, filtered to active employees only
- This is a good candidate to literally add as a 4th cron alongside the existing 3, following
  the same off-peak scheduling and indexing guidance already given.

### 2.4 Falsified/suspicious attendance record → flag for manual discipline review
**Trigger:** a manager or HR notices (or a separate anomaly-detection process flags) an
attendance record that looks manually altered, backdated, or inconsistent with device logs.
**What should happen:** this genuinely needs human judgment to initiate — don't auto-create
anything. Instead, add a **"Flag for Discipline Review" button** directly on the `hr.attendance`
form (visible to managers/HR), which opens a pre-filled `discipline.case` creation wizard
(employee, incident date, and a reference back to the specific attendance record already
populated) so the person doesn't have to re-enter data, but a human always clicks the button.
**How to implement:** a simple `action_flag_for_discipline()` method on `hr.attendance` that
returns an `ir.actions.act_window` opening a pre-filled `discipline.case` form — no
automation/cron needed at all, this is pure UI convenience.

### 2.5 Attendance summary data available when creating/reviewing a discipline case (FR-ATT-031)
**Trigger:** none — this is a display requirement, not an event.
**What should happen:** when HR opens a discipline case (especially one involving an
attendance-category offense), show the employee's attendance summary (absence count, lateness
count, last N records) directly on the case form for context.
**How to implement:** a **computed, non-stored field** on `discipline.case` (e.g.
`attendance_summary_html` or a few integer fields like `recent_absence_count`,
`recent_lateness_count`) computed on-demand when the case form is opened — not stored, not
cron-driven, since it's purely informational and only needs to be fresh when someone's actually
looking at it. This is the textbook "computed field, no polling" case from the cron-performance
file's decision table.

---

## Data/field additions needed to support Section 2

- A seeded `discipline.offense` record (or a small set of them) specifically for attendance
  misconduct categories: "Repeated Unexcused Absence," "Job Abandonment," each mapped to an
  appropriate severity level — confirm exact levels with HR/the BRD owner, since the BRD names
  the offense *categories* (implied by the `ATT` category you already seeded) but doesn't give
  exact thresholds or severity mappings for these specific attendance offenses.
- Configurable threshold fields somewhere sensible (e.g. `res.config.settings` or a small
  `discipline.attendance.policy` settings model) for: unexcused-absence count/window,
  lateness count/window, job-abandonment day count — don't hardcode these in Python, since the
  BRD doesn't specify exact numbers and the client will likely want to tune them.
- A link field on `discipline.case` back to the triggering attendance record(s)/pattern, so a
  case auto-drafted from Section 2 shows its evidence trail (which specific dates triggered it).

---

## Priority order for this section

1. **2.5 (attendance summary on case form)** — pure display, no automation risk, quick win.
2. **2.4 (manual flag button)** — pure UI convenience, no automation risk, quick win.
3. **2.3 (job abandonment cron)** — the one legitimate new cron; follow the off-peak +
   indexed-query pattern from the cron-performance file exactly.
4. **2.1 (repeated absence auto-draft)** — needs the offense data + threshold config first;
   implement as a narrowly-scoped automated action once those exist.
5. **2.2 (lateness notification)** — same automated-action pattern as 2.1, lower priority since
   it's a softer signal.
6. **Section 1 items (1.1, 1.3)** — the denormalized-field performance fix; do this whenever
   you're already in `hr_attendance.py` for Section 2 work, since it touches the same file.
