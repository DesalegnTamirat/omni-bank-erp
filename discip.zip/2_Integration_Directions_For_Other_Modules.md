# Integration Directions — What Other Module Teams Need From (and Owe To) Discipline Management

Give this file to whoever is building the other modules (Recruitment, Payroll, ESS,
Analytics/Dashboard). It defines the contract: what `discipline_management` already exposes
for them to consume, and what they need to build/send back so the BRD's cross-module
requirements (FR-INT-xxx, FR-REC-xxx, FR-DA-xxx, FR-DASH-xxx) are actually satisfied.

**Rule of thumb we're following:** logic and state that *originates* in Discipline (is an
employee currently ineligible? is the appeal window open? what's the penalty amount?) is owned
and computed **inside `discipline_management`**. Other modules should call into it, not
reimplement the rule themselves. This came up already with the appeal-window question — the
open/closed logic for "Submit Appeal" lives in `discipline.case.is_appeal_window_open`, not in
whatever module renders the button.

---

## 1. Recruitment Module (FR-REC-022, FR-REC-068, FR-REC-073, FR-INT-004, FR-INT-016)

**What we already expose:**
- `hr.employee.check_discipline_eligibility()` → returns `(is_eligible: bool, reason: str)`.
  Checks active suspension and enforced cases within the last 12 months (duration will become
  configurable per offense level once Task 8 in the implementation-prompt file lands).
- `hr.employee.active_disciplinary_action` (Boolean), `disciplinary_warning_count` (Integer),
  `is_suspended` (Boolean) — quick-read flags if you don't need the full reason string.
- `hr.employee.discipline_case_ids` — full case history for a candidate, for the "make
  disciplinary records available to recruitment/promotion processes" requirement (FR-DIS-038 /
  FR-INT-016). Cases are read-only once enforced (record-level readonly, not deletable).

**What Recruitment needs to build:**
- When pulling a candidate list for an internal vacancy or promotion (FR-REC-022, FR-REC-068),
  call `check_discipline_eligibility()` per candidate and filter/grey out ineligible ones
  automatically — don't just show a warning, actually exclude them from the selectable list.
- If an HR user manually tries to select an ineligible candidate anyway, show the exact error
  text the BRD specifies: *"Candidate is currently ineligible for promotion due to an active
  disciplinary penalty."* — pull the `reason` string from our method for the specific detail,
  but the headline error text should match the BRD wording since that's what the client asked
  for.
- FR-REC-073 ("reject applications if active disciplines available") — same method, called at
  application-submission time, not just candidate-list-filtering time.

**What we still need from you (nothing currently, but flag if):** if Recruitment tracks its
own separate "disciplinary hold" concept, don't — treat our `is_eligible` flag as the single
source of truth so the two modules can't disagree.

---

## 2. Payroll Module (FR-DIS-023, FR-INT-014)

**What we already expose:**
- `discipline.payroll.penalty` records, auto-created when a case is approved
  (`penalty_percentage`, `calculated_amount`, `effective_date`, `state`). Currently
  `calculated_amount` is only an **estimate** off `hr.contract.wage` — it is not yet a real
  payslip line (see the implementation-prompt file, Task 2).
- A manual "Transmit to Payroll" action (`action_transmit_to_payroll`) that flips state to
  `transferred` — this is a placeholder until real integration exists.

**What we need from Payroll (this is the blocking dependency):**
- Confirm whether Payroll will be `hr_payroll` (Odoo's own) or a custom module, and what the
  correct target model/field is for a one-off deduction (`hr.payslip.input`,
  a custom `payroll.deduction.line`, etc.).
- Once that's confirmed, we'll replace `action_transmit_to_payroll` with real record creation
  on your side, triggered automatically (not manually) when a case is enforced.
- We also need a payroll-side way to **withhold pay entirely** for `without_pay` suspensions
  (currently we only block attendance check-in on our side — see the Attendance file, this
  doesn't touch actual pay calculation).
- For managerial staff, penalties are calculated in **daily wage units**, not percentages —
  Payroll needs to accept a day-count input, not just a percentage, once we send it.

**Timeline dependency:** Task 2 in the implementation-prompt file can't fully close until
Payroll confirms the target model/field above.

---

## 3. Analytics / Dashboard Module (FR-DA-047, FR-DA-INT-015, FR-DA-INT-016, FR-DASH-038, FR-DASH-039)

**What we already expose:**
- `discipline.case` — full case data (offense type, severity level, state, dates,
  department, job position). Case-volume and case-trend dashboards **within this module**
  already exist (`discipline_dashboard.py` + the JS widget) but that's scoped to Discipline's
  own screen, not the cross-module Analytics module the BRD describes separately.
- `discipline.payroll.penalty` — financial impact data (amounts, dates) for "discipline trends
  and financial impact" reporting (per the Module 9 Purpose statement).

**What Analytics needs to build:**
- A read model/query layer pulling from `discipline.case` and `discipline.payroll.penalty` —
  don't duplicate case data into Analytics' own tables; query or use a reporting view against
  ours so figures can't drift out of sync.
- FR-DA-INT-016 ("Analytics to Discipline: system shall provide discipline trends... back to
  Discipline") — if Analytics computes anything Discipline's own dashboard should display
  (e.g. cross-department benchmarking), expose it as a method/field we can call, following the
  same "logic lives where it originates" rule.

---

## 4. Employee Self-Service / Portal (FR-DIS-031, FR-DIS-032, FR-DIS-021.3)

**Important — read this before building anything here:**

Per the correction in the checklist review: the **appeal window open/closed state is owned by
Discipline Management**, not ESS. `discipline.case.is_appeal_window_open` is the single source
of truth. Per Task 1 in the implementation-prompt file, Discipline Management is adding its own
portal controller/template for appeal submission (depends on Odoo's `portal` module). Two ways
this can go, decide together:

- **Option A (recommended if no separate ESS module exists yet):** Discipline Management owns
  the appeal-submission page directly via its own portal controller. ESS just links to it.
- **Option B (if ESS is a substantial separate module already):** ESS renders the page, but
  every read of "is the window open" and every POST of a new appeal must call into
  `discipline.appeal`/`discipline.case` methods — ESS must not reimplement the 10-day rule or
  compute its own open/closed flag.

Either way, **do not duplicate the 10-day window calculation anywhere else.**

**What ESS also needs to handle (ESS's actual responsibility, not ours):**
- FR-DIS-021.3: disable/hide the "Request Transfer" button on the employee portal when
  `hr.employee.active_disciplinary_action` or `is_suspended` is true, or return a blocking
  error message if they try anyway. This check is on ESS's side (it's ESS's button), but it
  must read our flag, not maintain its own copy.
- FR-DIS-021.4: Forced/Administrative Transfer processing for HR/Management — this is an
  HR-workflow feature outside Discipline's scope; just make sure whatever transfer logic exists
  checks our flags the same way.

---

## 5. Attendance Module

Attendance is covered in its own dedicated file (`4_Attendance_Discipline_Scenarios.md`) since
you own both modules — that file has the full bidirectional scenario list and won't be repeated
here.

---

## Quick contract summary table

| Other module | Reads from Discipline | Writes to Discipline | Discipline still owes them |
|---|---|---|---|
| Recruitment | `check_discipline_eligibility()`, `discipline_case_ids` | — (read-only) | Nothing blocking; method is ready |
| Payroll | `discipline.payroll.penalty` records | Confirms deduction was applied (`state='deducted'`) | Real payslip-line creation (needs Payroll's model/field decision first) |
| Analytics | `discipline.case`, `discipline.payroll.penalty` | Trend/benchmark data back (optional) | Nothing blocking |
| ESS/Portal | `is_appeal_window_open`, `active_disciplinary_action`, `is_suspended` | New `discipline.appeal` records (via our method, window-checked) | Portal controller/template (Task 1, in progress) |
| Attendance | `is_suspended`, `suspension_type` | Absence/lateness pattern signals (see dedicated file) | FR-INT-010 direction (see dedicated file) |
