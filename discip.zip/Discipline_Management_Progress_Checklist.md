# Discipline Management Module — Progress vs BRD (Module 9)
**BRD Reference:** ERP HR MODULES UPGRADE AND ENHANCEMENT – BRD, Section 16 (FR-DIS-001 to FR-DIS-041)
**Code Reviewed:** `discipline_management.zip` (Odoo 19 module — 12 models, 10 views, security, wizard, reports, tests, cron)

---

## Overall Completion: ~80%

| Status | Count (out of 41 FRs) |
|---|---|
| ✅ Fully implemented | 25 |
| 🟡 Partially implemented | 16 |
| ❌ Not started | 0 (all have *some* scaffolding) |

The **core case lifecycle (initiate → investigate → committee → approve → enforce → appeal → revoke)** is solidly built and matches the BRD state machine well. What's left is mostly **money-calculation edge cases, cross-module wiring, and a few structured-data fields** the BRD spells out in sub-bullets that didn't make it into the models yet.

---

## 1. Offense Classification (FR-DIS-001 to 005)

- [x] **FR-DIS-001** Offense category/level configuration (admin-only) — `discipline_offense.py`
  - [ ] ⚠️ Sub-rule not built: "record locks once HR notifies committee; unlocks on committee feedback" — no lock/unlock field or logic exists anywhere.
- [x] **FR-DIS-002** Offense → Severity/Description/Punishment/Approval Authority mapping
- [x] **FR-DIS-003** Standard 5-level offense matrix (auto-populated via `@onchange` + seeded in `discipline_offense_data.xml`)
- [x] **FR-DIS-004** Modification prevention (create/write restricted to `group_discipline_admin`)
- [x] **FR-DIS-005** Policy version control (`discipline_policy_version.py` + mail.thread tracking)

**Section status: 90% done** — only the committee-notify lock/unlock micro-flow is missing.

---

## 2. Case Lifecycle Management (FR-DIS-006 to 012)

- [x] **FR-DIS-006** Case initiation — 🟡 any `discipline_user`/`officer` can initiate; not scoped specifically to "Audit Directorate" as the BRD names. Consider a dedicated group or department restriction.
- [x] **FR-DIS-007** Mandatory fields (Employee, Offense, Date, Description) — all `required=True`
- [x] **FR-DIS-008** Document attachment (native Odoo chatter attachments)
- [x] **FR-DIS-009** Duplicate case prevention — 🟡 blocks same employee+date+**same offense**, but the BRD's finer sub-rules aren't coded: "penalty has an active duration" and "cannot record identical **penalty level** twice same day" (different offense, same level) are not checked.
- [x] **FR-DIS-010** Workflow routing — 🟡 state machine exists (`action_initiate`→...→`action_approve_and_enforce`), but it's **manually button-driven**, not auto-routed "based on Offense Level and Organizational Hierarchy" as required.
- [x] **FR-DIS-011** Approval restriction — 🟡 only Level 1/Dismissal is hard-restricted to HR Admin. The BRD's specific split (**CEO** approves Division-Manager-and-above cases, **CPCO** approves everything below) is not implemented — no job-level check exists.
- [x] **FR-DIS-012** SLA escalation — done (`sla_deadline` compute + daily cron `_cron_check_sla_escalations`)

**Section status: ~65% done** — the routing/approval-authority logic is the biggest functional gap here.

---

## 3. Investigation & Documentation (FR-DIS-013 to 015)

- [x] **FR-DIS-013** Investigation recording — 🟡 **only 3 free-text fields exist** (`summary_findings`, `witness_statements`, `investigator_recommendation`). The BRD specifies a structured 8-part report format:
  - [ ] Title/Subject
  - [ ] Introduction
  - [ ] Scope & Limitations
  - [x] Investigation Findings (covered by `summary_findings`)
  - [ ] Financial Shortage/Loss Amount (if applicable)
  - [ ] Resolution Status (Resolved/Unresolved)
  - [ ] Liable Employees & specific Policy Article references (currently no field to list multiple liable staff)
  - [x] Recommendations (covered by `investigator_recommendation`)
- [x] **FR-DIS-014** Evidence attachment (optional) — done, 3 binary fields (report/evidence/statement)
- [x] **FR-DIS-015** Full audit log — done via `mail.thread` on all models

**Section status: ~55% done** — needs a model rework to add the missing structured fields.

---

## 4. Disciplinary Committee (FR-DIS-016 to 020)

- [x] **FR-DIS-016** Committee scheduling — 🟡 has date/time, location, multi-select members, case link, auto-notify on schedule. Missing: explicit **end time** field (BRD wants start+end), and the notification is a chatter message rather than a formal templated email/alert.
- [x] **FR-DIS-017** Participant notification — done (`action_schedule_and_notify`)
- [x] **FR-DIS-018** Minutes recording — done (`meeting_minutes` + `action_record_minutes_and_votes`)
- [x] **FR-DIS-019** Decision & vote capture — 🟡 votes/recommendation captured well, **but the salary-penalty calculation logic described in the BRD is not implemented**:
  - [ ] Managerial staff → **daily wage units** (Verbal=0, 1st=1 day, 2nd=2 days, 3rd=3 days) — current payroll model only does flat percentage, no managerial/non-managerial branch
  - [ ] Non-managerial → percentage (5/10/20%) — this part **is** covered
  - [ ] Demotion → basic salary untouched, but allowances/benefits recalculated to new grade — **not implemented anywhere**
- [x] **FR-DIS-020** Quorum validation — 🟡 percentage-based quorum check works (`_compute_quorum`), but the BRD's specific **3-step sequential sign-off** (1. Immediate Director signs first → 2. Committee members vote → 3. CEO/CPCO approval button stays locked until 1 & 2 complete) is not modeled — there's no locking mechanism tied to signatory order.

**Section status: ~60% done** — this is the second-biggest gap area (penalty calc + signatory sequencing).

---

## 5. Decision Enforcement (FR-DIS-021 to 025)

- [x] **FR-DIS-021** Automatic enforcement — mixed:
  - [x] Payroll deduction auto-created on approval
  - [x] `active_disciplinary_action` flag set → basis for promotion ineligibility
  - [ ] Actual **block on Recruitment candidate lists** + the specific error message — not present because the Recruitment module isn't part of this package; only the `check_discipline_eligibility()` hook exists for Recruitment to call
  - [ ] **Self-Initiated Transfer Request** button disable on ESS — not present (ESS module not in this package)
  - [ ] **Forced/Administrative Transfer** processing — not present
  - [ ] Validity/expiry of the promotion block is hardcoded to a flat 12 months rather than tied to each offense level's actual "legal active period" (BRD doesn't fully define these durations either — worth confirming with the client)
- [x] **FR-DIS-022** Action implementation — mixed:
  - [ ] Document generation: a report template exists (`discipline_report_templates.xml`) but is **not auto-triggered/attached** on approval — currently print-only, manual
  - [x] Payroll integration record created automatically
  - [ ] Master Data updates: job grade / benefit scale changes on **Demotion** are not implemented
- [x] **FR-DIS-023** Payroll integration — 🟡 penalty record auto-**created**, but "transmitted" is a **manual button** (`action_transmit_to_payroll`), not automatic — and there's no real Payroll module to push into yet (see Integration Gaps below)
- [x] **FR-DIS-024** Dismissal handling — done, auto-triggers `_process_employee_dismissal()`
- [x] **FR-DIS-025** Access revocation — done, disables `user_id` on dismissal

**Section status: ~55% done**

---

## 6. Suspension Management (FR-DIS-026 to 030)

- [x] **FR-DIS-026** Suspension initiation — done
- [x] **FR-DIS-027** Suspension type (With/Without Pay) — done
- [x] **FR-DIS-028** Max 30 working-day enforcement — done (`_check_max_duration` constraint)
- [x] **FR-DIS-029** Automated tracking + expiry notice — done (daily cron, alerts HR 3 days before expiry)
- [x] **FR-DIS-030** Suspension from work/salary/benefits — 🟡 attendance check-in is correctly blocked for "without pay" suspensions (nice touch, in `hr_attendance.py`), but there's **no actual payroll-side salary withholding** hook — module doesn't depend on `hr_payroll` at all.

**Section status: ~90% done** — best-covered section, only the payroll-withholding link is missing.

---

## 7. Appeal & Review (FR-DIS-031 to 034)

- [x] **FR-DIS-031** Appeal submission within 10 calendar days — backend constraint enforced (`_check_appeal_window`)
  - [ ] ⚠️ **Correction (per review): this is NOT an ESS-module concern.** The open/closed state of the "Submit Appeal" action is already computed *inside this module* — `discipline.case.is_appeal_window_open` (see `discipline_case.py`, `_compute_is_appeal_window_open`). Whatever screen an employee uses to submit an appeal, it has to read that field to know whether to show the button as open or locked — so the logic itself belongs here, not in ESS. What's actually missing is:
    - No employee-facing **create button/action is gated on `is_appeal_window_open`** yet — right now the only enforcement is the `_check_appeal_window` ORM constraint, which rejects a late submission *after* the fact rather than hiding/disabling the action before the employee tries.
    - No **portal page or controller exists in this module at all** — the manifest doesn't even depend on Odoo's `portal` module, so there's currently no self-service surface for an employee to submit an appeal from outside the backend. If a separate ESS/portal module ends up rendering the "My Requests" page, it should call into this module's field/logic rather than reimplement the 10-day rule — but the page itself may need to live here if no ESS module exists yet.
- [x] **FR-DIS-032** Auto-close appeal window — 🟡 the underlying rule (`is_appeal_window_open`, `appeal_deadline`) is fully owned and enforced here; a daily cron also posts a reminder. What's missing is wiring an actual UI element (button `invisible`/`readonly` attribute, or a portal page) to that already-computed field so it visibly locks — see fix plan in the companion implementation-prompt file.
- [x] **FR-DIS-033** Appeal routing to higher authority/committee — 🟡 `reviewer_id` field + manual assignment exists; no automatic routing rule based on original case severity
- [x] **FR-DIS-034** Appeal tracking (status/outcome/revised action) — done, and nicely reverses payroll penalties / employee flags on overturn

**Section status: ~75% done**

---

## 8. Disciplinary History (FR-DIS-035 to 038)

- [x] **FR-DIS-035** Complete non-editable record — done (`unlink()` blocks deletion of enforced/closed/appealed cases)
- [x] **FR-DIS-036** Read-only after finalization — done at the **view level** (fields become readonly when `state in ('enforced','closed','revoked')`)
- [x] **FR-DIS-037** Full audit trail (User/Timestamp/Change) — done via `mail.thread` tracking everywhere
- [x] **FR-DIS-038** Recruitment eligibility integration — done as an exposed method (`check_discipline_eligibility()`); actual consumption by the Recruitment module is pending that module's build

**Section status: 100% done** on this module's side.

---

## 9. Revocation & Correction (FR-DIS-039 to 041)

- [x] **FR-DIS-039** Revocation authority restricted to HR Admin — done
- [x] **FR-DIS-040** Mandatory justification + approval workflow — done (`discipline_revocation_wizard.py`)
- [x] **FR-DIS-041** Original record preserved, non-deletable — done

**Section status: 100% done.** This is the cleanest, most complete part of the module.

---

## 10. Cross-Module Integration Points (owned partly by other modules)

These FRs live in other BRD sections but reference Discipline data. Your module should expose the right hooks even if the other side isn't built yet:

| FR | Direction | Status |
|---|---|---|
| FR-REC-022 / FR-REC-068 / FR-REC-073 | Recruitment → Discipline (block ineligible candidates) | 🟡 Hook exists (`check_discipline_eligibility`), Recruitment module not built yet |
| FR-INT-004 | Recruitment → Discipline | 🟡 same hook, pending Recruitment side |
| FR-INT-010 | **Attendance → Discipline** (auto-initiate/update a case from attendance issues) | ❌ Not built — your `hr_attendance.py` only goes the *other* direction (Discipline restricting attendance), not attendance triggering a case |
| FR-INT-014 | Discipline → Payroll | 🟡 Penalty record created, but module doesn't depend on `hr_payroll` — no real payslip line is generated |
| FR-INT-015 | Discipline → Separation | ✅ Covered via `_process_employee_dismissal()` |
| FR-INT-016 | Discipline → Recruitment (history visibility) | ✅ `discipline_case_ids` on `hr.employee` exposes full history |
| FR-DA-047 / FR-DA-INT-015/016 | Discipline → Analytics | 🟡 Raw data exists on `discipline.case`; no dedicated analytics export yet (Analytics module not built) |
| FR-DASH-038/039 | Discipline case dashboards/trends | ✅ Your own `discipline_dashboard.py` + JS widget already covers case volumes/trends within this module |
| FR-EMP-010 | Mask discipline field for unauthorized users | ⚠️ Not verified — worth checking `hr_employee_views.xml` for field masking |

---

## 11. Code-Quality Issues Found (fix these regardless of BRD mapping)

1. **`discipline_dashboard.py` state-filter bugs**: `investigations` count filters on `state != 'concluded'`, but `discipline.investigation` has no `'concluded'` state (it's `draft/submitted/approved`) — this makes the filter a no-op (always counts everything). Same issue for `committee_meetings` filtering `not in ['concluded','cancelled']` — should be `not in ['completed','cancelled']`.
2. **`discipline_suspension.py`**: `state` selection includes `'converted_dismissal'` but there is no `action_*` method anywhere that transitions a suspension into that state — dead code / unfinished feature.
3. **Manifest doesn't depend on `hr_payroll`** — this is why penalty amounts are only *estimated* off `hr.contract.wage` rather than posting a real payslip input line. Needs a decision: either add the dependency now, or explicitly flag this as a stub awaiting the Payroll module.
4. **Test coverage is thin**: only 5 tests exist (`test_discipline_case.py`) — duplicate prevention, segregation of duties, suspension max duration, appeal window, eligibility check. No tests for: offense config permissions, committee quorum, revocation flow, payroll penalty calculation, dismissal handling, or cron jobs.

---

## Suggested Priority Order to Resume Work

1. **Payroll penalty logic rewrite** (FR-DIS-019, 021, 022, 023, 030) — add managerial vs non-managerial branching, daily-wage-unit calc, demotion benefit recalculation, and decide on the `hr_payroll` dependency question. This is the single biggest cluster of gaps.
2. **Approval authority by job level** (FR-DIS-011) — CEO vs CPCO routing based on whether the employee is Division Manager and above.
3. **Investigation model rework** (FR-DIS-013) — add the missing structured fields (Title, Introduction, Scope, Financial Loss, Resolution Status, Liable Employees list).
4. **Committee sequential sign-off** (FR-DIS-020) — Director-first → Committee → locked CEO/CPCO button.
5. **Auto-generate & attach the warning letter PDF** on `action_approve_and_enforce` instead of leaving it print-only (FR-DIS-022).
6. **Fix the two dashboard state-filter bugs** and remove/finish the dead `converted_dismissal` state.
7. **FR-INT-010**: build the Attendance→Discipline direction (currently only Discipline→Attendance exists).
8. **Expand test suite** to cover committee, revocation, payroll, and cron logic.
9. Lower priority / can wait for other module builds: ESS portal button states (FR-DIS-031/032), Recruitment candidate blocking UI (FR-DIS-021.2), Forced Transfer processing (FR-DIS-021.4) — these need modules outside this package to exist first.

---

## Quick Resume Reference

- **Module path:** `discipline_management/`
- **Core state machine:** `models/discipline_case.py` → `draft → initiated → investigating → committee_review → pending_approval → enforced → (appealed/revoked) → closed`
- **Where penalties are calculated:** `models/discipline_payroll.py` (`_compute_calculated_amount`) — this is where the managerial/non-managerial fix belongs
- **Where committee logic lives:** `models/discipline_committee.py` (`_compute_quorum`, `action_finalize_meeting`)
- **Where the letter template lives:** `report/discipline_report_templates.xml` — needs to be wired into `action_approve_and_enforce()` in `discipline_case.py`
- **Cron jobs:** `data/discipline_cron.xml` (SLA, suspension expiry, appeal window — all daily)
- **Security groups:** `discipline_user < discipline_officer < discipline_manager < discipline_admin` (defined in `security/discipline_security.xml`)
