# Cron Usage — Current State, Real Risk, and Lighter-Weight Alternatives

## Short answer up front

The 3 crons that exist today are **not actually a check-in/check-out performance risk** —
they run once a day, not during attendance transactions. The real risk to watch is a
**different mechanism**: the `hr.attendance` compute field and Python constraint that fire on
every single check-in/check-out write. That's the part worth fixing, and it doesn't need a
cron at all. Details below, then concrete recommendations, per your ask, for lighter-weight
alternatives to cron wherever one applies.

---

## 1. Audit of the 3 existing crons

| Cron | Model | Frequency | What it does | Risk level |
|---|---|---|---|---|
| `ir_cron_discipline_case_sla_check` | `discipline.case` | Daily | Searches breached-SLA cases, posts a chatter alert | Low — scoped `search()`, once/day |
| `ir_cron_discipline_suspension_expiry_check` | `discipline.suspension` | Daily | Searches suspensions expiring within 3 days, posts alert | Low — same pattern |
| `ir_cron_discipline_appeal_window_expiry_check` | `discipline.case` | Daily | Searches cases past appeal deadline, posts a chatter note | Low — same pattern |

**None of these run near check-in/check-out.** They're scheduled once daily (Odoo's default
`ir.cron` next-call time is midnight unless set otherwise) and query a small, filtered subset
of records. At your current and near-term data volume, these are not a performance concern by
themselves.

**Two things worth tightening anyway, cheaply:**
1. **Set explicit off-peak run times.** Right now they just use `interval_number=1,
   interval_type=days` with no explicit hour set on `nextcall`. Pin all three to something
   like 1:00–2:00 AM (`nextcall` field) so they never have a chance to overlap with morning
   check-in traffic (typically 7:30–9:00 AM) or evening check-out traffic, even as data grows.
2. **Add database indexes** on the fields these crons filter on, since a `search()` without an
   index becomes a full table scan as case/suspension volume grows:
   - `discipline.case`: `index=True` on `sla_deadline`, `appeal_deadline`, `is_sla_exceeded`,
     `state`
   - `discipline.suspension`: `index=True` on `end_date`, `state`
   This is a one-line change per field (`fields.Date(..., index=True)`) and costs nothing at
   current scale, but prevents these crons from becoming slow later without anyone noticing.

---

## 2. The actual hot-path risk: `hr_attendance.py`, not cron

Look at `models/hr_attendance.py`:

```python
@api.depends('employee_id', 'check_in')
def _compute_is_suspended_attendance(self):
    ...

@api.constrains('employee_id', 'check_in')
def _check_unpaid_suspension_attendance(self):
    ...
```

Both of these run **synchronously on every `hr.attendance` create/write** — i.e. on every
single check-in. `@api.constrains` in Odoo is a **Python-level check**, not a database
constraint: it loads each modified record, evaluates the condition in Python, and raises if it
fails. This is fine for one employee checking in. It becomes a real cost when:
- A biometric device or badge system does a **bulk sync** (e.g. importing hundreds of
  check-in/check-out events from an offline device at shift start), because each record in the
  batch triggers its own constraint evaluation and (if the ORM doesn't fully prefetch) its own
  read of `employee_id.is_suspended`.
- Many employees check in within the same few minutes (the literal 8:00 AM rush) — each is a
  separate transaction hitting the same code path at once.

This is the part that can genuinely compete for resources at check-in/check-out time, not the
daily crons.

**Fix — no cron needed, and this is exactly the kind of case where a cron would be the wrong
tool anyway:**

1. **Move the hard block to a database-level constraint** instead of (or in addition to) the
   Python one, so the database itself rejects the invalid row without Odoo needing to load and
   evaluate Python for every record:
   ```python
   _sql_constraints = [
       # Not directly expressible as a plain SQL CHECK since it needs a join to hr.employee,
       # so in practice: keep a denormalized boolean copied onto hr.attendance at create time
       # (see point 2) and check constraint against THAT column instead of following a relation.
   ]
   ```
   Practically: add a stored `is_currently_suspended_without_pay` boolean that's **copied
   directly onto the attendance record at create time** (a plain field set once, not a live
   compute), so validation becomes a simple local-column check instead of a cross-model lookup
   on every write. A CHECK constraint can then reference that local column cheaply.

2. **Batch-friendly validation for imports.** If check-in data arrives via bulk import/API
   (common for biometric devices), don't rely on the per-record ORM constraint to catch
   suspended employees one at a time — pre-filter the whole batch in one query before creating
   any records: fetch the set of currently-suspended-without-pay employee IDs once
   (`self.env['hr.employee'].search([('is_suspended','=',True),('suspension_type','=','without_pay')])`),
   then filter the incoming batch against that set in Python before calling `create()`. One
   query instead of N.

3. **Keep the compute field for display, drop it as the enforcement mechanism.** The
   `is_suspended_attendance` compute field is fine to keep for showing a badge/note on the
   attendance record — that's cheap and only recomputes when `check_in` is set (i.e. once per
   record, not repeatedly). Just don't let display-only computes double as your only
   enforcement layer; pair them with the database-level check above.

---

## 3. General principle for "cron vs. something lighter" going forward

Since you're right that more crons are likely as the module grows, here's the decision rule to
apply each time before adding a new one:

| Need | Right tool | Why |
|---|---|---|
| **"Show whether X is currently true"** on a form (SLA breached? appeal window open? suspension expiring soon?) | **Computed field** (`@api.depends`, optionally `store=True`) | Costs nothing until the record is actually viewed/searched; no polling needed at all. This is already how `is_sla_exceeded`, `is_appeal_window_open`, `days_remaining` work — keep doing this for anything that's purely informational. |
| **"Reject an invalid write"** (e.g. block attendance for suspended staff) | **Database constraint on a denormalized local field**, not a cross-model Python `@api.constrains` | Runs at the database layer, cheap even under bulk load; see section 2 above. |
| **"Something needs to happen automatically when a specific record changes"** (e.g. auto-create a discipline case when an attendance pattern crosses a threshold) | **Automated Action (`base.automation`) triggered on write/create of the specific model**, scoped as narrowly as possible | Runs only when the triggering record actually changes, not on a blind schedule — but keep the triggering domain narrow (e.g. only fire on the *Nth* consecutive absence, not on every attendance write) or it becomes the same hot-path problem as section 2. |
| **"Notify someone that a deadline is approaching/has passed"** (SLA breach, suspension expiry, appeal window closing) | **Cron, but daily and off-peak** | This is the one case that genuinely needs polling — Odoo has no native "fire at a future date" event system without extra infrastructure (a task queue like `queue_job` or Celery-equivalent). A once-daily cron at 1–2 AM is the right-sized tool; just don't schedule it more frequently than the business need actually requires, and don't scope its query broadly. |
| **"Recompute a value across many records periodically"** (e.g. nightly recalculation of eligibility windows) | **Cron, but only if the value truly can't be a live compute** | Prefer a compute field first; only fall back to a cron+stored-field pattern if the calculation is genuinely too expensive to run on every read. |

**Rule of thumb:** if the answer to "does this need to happen at a specific wall-clock time
regardless of any record changing" is yes → cron (daily, off-peak). If the answer is "this
needs to react to a specific record changing" → automated action, narrowly scoped. If the
answer is "this is just a fact I want to display" → computed field, no polling at all.

---

## 4. If it does grow to "many crons" later

A few safeguards worth adopting once you have more than the current 3:

1. **Stagger `nextcall` times** across crons (1:00, 1:15, 1:30 AM, etc.) instead of letting
   several land at the exact same minute — avoids them all competing for the same worker at
   once even if none of them individually is expensive.
2. **Set `priority` and `numbercall` deliberately** — a runaway or misconfigured cron
   (`numbercall = -1` with a very short interval) is the actual way a system gets "busy," not
   a well-scoped daily job. Review this on every new cron before it ships.
3. Consider **Odoo's queue/worker configuration** (`--max-cron-threads`) if you eventually do
   need several crons running close together — this is an infrastructure-level lever separate
   from anything in the module code, worth knowing about but not needed at your current scale.
4. If you eventually need genuinely real-time cross-system triggers (not just "once a day is
   fine"), that's a sign you need a proper job queue module (e.g. `queue_job`) rather than more
   `ir.cron` records — but that's a bigger infrastructure decision, flag it before building
   toward it.

---

## Bottom line

- Your current 3 crons are fine as-is; just pin off-peak `nextcall` times and add the indexes
  listed in section 1 as cheap insurance.
- The thing that can actually slow down check-in/check-out is the `hr_attendance.py`
  constraint doing a cross-model lookup on every write — fix that with a denormalized local
  field + batch pre-filtering for imports (section 2), not with a cron.
- Going forward, default to computed fields for anything display-only, automated actions
  (narrowly scoped) for anything reactive, and reserve cron for genuinely time-based
  notifications only.
