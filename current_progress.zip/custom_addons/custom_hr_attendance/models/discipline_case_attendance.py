# -*- coding: utf-8 -*-
import logging
from datetime import timedelta
from odoo import models, api, fields, _

_logger = logging.getLogger(__name__)


class DisciplineCaseAttendance(models.Model):
    """
    Attendance-side inherit of discipline.case.
    Provides the factory method _create_from_attendance, called by the attendance
    module when a violation threshold is exceeded.

    Segregation of duties is preserved: this method only sets the case to
    'initiated' state. A human reviewer and approver are still required
    to progress the case — nothing here bypasses discipline_management's workflow.
    """
    _inherit = 'discipline.case'

    @api.model
    def _create_from_attendance(self, employee_id, kind, attendance_id):
        """
        Creates and initiates a discipline case triggered by an attendance violation.
        Called asynchronously from the attendance hot path after threshold is reached.

        kind: 'lateness', 'force_checkout', or 'absence'
        attendance_id: the hr.attendance record ID that triggered this case (0 for absence).
        Returns the created discipline.case record, or None if the offense is not found.
        """
        kind_map = {
            'lateness': 'custom_hr_attendance.offense_repeated_lateness',
            'force_checkout': 'custom_hr_attendance.offense_repeated_force_checkout',
            'absence': 'custom_hr_attendance.offense_repeated_absence',
        }
        offense_xmlid = kind_map.get(kind, 'custom_hr_attendance.offense_repeated_lateness')
        offense = self.env.ref(offense_xmlid, raise_if_not_found=False)
        if not offense:
            _logger.warning(
                "Discipline offense '%s' not found. Skipping attendance case creation for employee %s.",
                offense_xmlid, employee_id
            )
            return None

        kind_labels = {
            'lateness': _('Repeated Lateness'),
            'force_checkout': _('Repeated Force Checkout'),
            'absence': _('Repeated Absence'),
        }
        kind_label = kind_labels.get(kind, kind)
        case = self.create({
            'employee_id': employee_id,
            'offense_id': offense.id,
            'description': _(
                'Automatically flagged by the Attendance module: violation threshold for %s exceeded.\n'
                'Source attendance record ID: %s.\n'
                'Human review and approval are required before enforcement.'
            ) % (kind_label, attendance_id),
            'reference': 'ATT-%s' % attendance_id,
        })

        # Move to 'initiated' state: the system is the initiator only.
        # Reviewer and approver must be different users (segregation of duties enforced by discipline.case).
        if hasattr(case, 'action_initiate'):
            case.action_initiate()

        _logger.info(
            "Attendance discipline case %s created for employee %s (kind=%s, attendance=%s).",
            case.name, employee_id, kind, attendance_id
        )
        return case


class HrAttendanceViolationProcessor(models.Model):
    """
    Attendance-side violation counter processing logic.

    Extends hr.attendance with _process_attendance_violation_counters, which is
    called by _enqueue_attendance_side_effects after check-in/check-out.

    ATT-6: Counters now use a configurable rolling time window (default 30 days).
    Only violations within the window count toward the discipline threshold, preventing
    accumulation of stale violations from months ago triggering discipline cases today.

    Architecture note:
    - Counter check: SQL COUNT over the time window — single fast indexed query.
    - Threshold check + case creation: synchronous but rare (only on threshold breach).
    - The discipline case create+initiate only triggers when threshold is crossed.
    """
    _inherit = 'hr.attendance'

    def _process_attendance_violation_counters(self):
        """
        ATT-6: Counts rolling violations within a configurable time window and creates
        a discipline case when the configured threshold is exceeded.

        Called by _enqueue_attendance_side_effects after each check-in/check-out.
        """
        self.ensure_one()
        employee = self.employee_id
        if not employee:
            return

        params = self.env['ir.config_parameter'].sudo()

        # ATT-6: Rolling window in calendar days (default: 30 days)
        window_days = int(params.get_param('hr_attendance.violation_window_days', 30))
        window_start = fields.Datetime.now() - timedelta(days=window_days)

        # --- LATE CHECK-IN COUNTER (within time window) ---
        if self.check_in_status == 'Late':
            lateness_threshold = int(params.get_param(
                'hr_attendance.lateness_violation_threshold', 3
            ))
            # Count late check-ins within the rolling window (excludes current record before commit)
            late_count = self.search_count([
                ('employee_id', '=', employee.id),
                ('check_in_status', '=', 'Late'),
                ('check_in', '>=', window_start),
                ('id', '!=', self.id),
            ]) + 1  # +1 for the current record being processed

            _logger.debug(
                "ATT-6: Employee %s late count in %d-day window: %d / %d threshold.",
                employee.name, window_days, late_count, lateness_threshold
            )
            if late_count >= lateness_threshold:
                self.env['discipline.case'].sudo()._create_from_attendance(
                    employee.id, 'lateness', self.id
                )
                _logger.info(
                    "ATT-6: Lateness threshold breached for %s (%d in %d days). Discipline case created.",
                    employee.name, late_count, window_days
                )

        # --- FORCE CHECKOUT COUNTER (within time window) ---
        if self.is_force_checkout:
            force_checkout_threshold = int(params.get_param(
                'hr_attendance.force_checkout_violation_threshold', 2
            ))
            force_count = self.search_count([
                ('employee_id', '=', employee.id),
                ('is_force_checkout', '=', True),
                ('check_in', '>=', window_start),
                ('id', '!=', self.id),
            ]) + 1

            _logger.debug(
                "ATT-6: Employee %s force checkout count in %d-day window: %d / %d threshold.",
                employee.name, window_days, force_count, force_checkout_threshold
            )
            if force_count >= force_checkout_threshold:
                self.env['discipline.case'].sudo()._create_from_attendance(
                    employee.id, 'force_checkout', self.id
                )
                _logger.info(
                    "ATT-6: Force checkout threshold breached for %s (%d in %d days). Discipline case created.",
                    employee.name, force_count, window_days
                )


    @api.model
    def _create_from_attendance(self, employee_id, kind, attendance_id):
        """
        Creates and initiates a discipline case triggered by an attendance violation.
        Called asynchronously from the attendance hot path after threshold is reached.

        kind: 'lateness' or 'force_checkout'
        attendance_id: the hr.attendance record ID that triggered this case.
        Returns the created discipline.case record, or None if the offense is not found.
        """
        offense_xmlid = (
            'custom_hr_attendance.offense_repeated_lateness' if kind == 'lateness'
            else 'custom_hr_attendance.offense_repeated_force_checkout'
        )
        offense = self.env.ref(offense_xmlid, raise_if_not_found=False)
        if not offense:
            _logger.warning(
                "Discipline offense '%s' not found. Skipping attendance case creation for employee %s.",
                offense_xmlid, employee_id
            )
            return None

        kind_label = _('Repeated Lateness') if kind == 'lateness' else _('Repeated Force Checkout')
        case = self.create({
            'employee_id': employee_id,
            'offense_id': offense.id,
            'description': _(
                'Automatically flagged by the Attendance module: violation threshold for %s exceeded.\n'
                'Source attendance record ID: %s.\n'
                'Human review and approval are required before enforcement.'
            ) % (kind_label, attendance_id),
            'reference': 'ATT-%s' % attendance_id,
        })

        # Move to 'initiated' state: the system is the initiator only.
        # Reviewer and approver must be different users (segregation of duties enforced by discipline.case).
        if hasattr(case, 'action_initiate'):
            case.action_initiate()

        _logger.info(
            "Attendance discipline case %s created for employee %s (kind=%s, attendance=%s).",
            case.name, employee_id, kind, attendance_id
        )
        return case


class HrAttendanceViolationProcessor(models.Model):
    """
    Attendance-side violation counter processing logic.

    Extends hr.attendance with _process_attendance_violation_counters, which is
    called by _enqueue_attendance_side_effects after check-in/check-out.

    Architecture note:
    - Counter increment: synchronous single-row SQL UPDATE (O(1), safe on hot path).
    - Threshold check + case creation: synchronous but fast (only reads integer field
      already incremented by SQL above, no search queries).
    - The discipline case create+initiate is done within this call but is acceptable
      because it only triggers when threshold is crossed (rare event relative to
      total check-ins), not on every single check-in.
    """
    _inherit = 'hr.attendance'

    def _process_attendance_violation_counters(self):
        """
        Increments rolling violation counters and creates a discipline case when
        the configured threshold is exceeded.

        Called by _enqueue_attendance_side_effects after each check-in/check-out.
        This is the ONLY place in the attendance module that writes to the
        violation counters, ensuring a single authoritative code path.
        """
        self.ensure_one()
        employee = self.employee_id
        if not employee:
            return

        params = self.env['ir.config_parameter'].sudo()

        # --- LATE CHECK-IN COUNTER ---
        if self.check_in_status == 'Late':
            lateness_threshold = int(params.get_param(
                'hr_attendance.lateness_violation_threshold', 3
            ))
            new_count = employee._increment_late_count()
            _logger.debug(
                "Employee %s late count: %d / %d threshold.",
                employee.name, new_count, lateness_threshold
            )
            if new_count >= lateness_threshold:
                employee._reset_late_count()
                self.env['discipline.case'].sudo()._create_from_attendance(
                    employee.id, 'lateness', self.id
                )

        # --- FORCE CHECKOUT COUNTER ---
        if self.is_force_checkout:
            force_checkout_threshold = int(params.get_param(
                'hr_attendance.force_checkout_violation_threshold', 2
            ))
            new_count = employee._increment_force_checkout_count()
            _logger.debug(
                "Employee %s force checkout count: %d / %d threshold.",
                employee.name, new_count, force_checkout_threshold
            )
            if new_count >= force_checkout_threshold:
                employee._reset_force_checkout_count()
                self.env['discipline.case'].sudo()._create_from_attendance(
                    employee.id, 'force_checkout', self.id
                )

